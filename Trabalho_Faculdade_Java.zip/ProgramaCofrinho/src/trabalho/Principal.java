package trabalho;

import java.util.ArrayList;

public class Principal {
	
	public static void main(String[] args) {
		
		Menu menu = new Menu();
		menu.MostrarMenu();


	}

}
